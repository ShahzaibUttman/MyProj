package ErrorHandling;

public class Calculator {

	int result;
	
	public int sum(int num1, int num2)
	{
		result = num1 + num2;
		return result;
	}
	
	public int sub(int num1, int num2)
	{
		result = num1 - num2;
		return result;
	}
	
	public int multiply(int num1, int num2)
	{
		result = num1 * num2;
		return result;
	}
	
	public int divide(int num1, int num2) throws Exception
		{
			if(num2 == 0)
			{
				Exception e = new ArithmeticException();
				throw e;
			}
			
			if(num2 != )
			{
				Exception e = new NumberFormatException();
				throw e;
			}
		
		result = num1 / num2;
		return result;
	}
    
     
	
}
