package ErrorHandling;

public class ArrayIndexOutOfBoundException {

		   public static void main(String args[]) {
			
			   try
			   {
			   int arr[] = new int[10];
			   arr[5] = 10/0 ;
			   }
			   
			   
			   catch(IllegalArgumentException e)
			   {
				   System.out.println("The specified index does not exist in array.");
			   }

			   catch(IllegalAccessException e)
			   {
				   System.out.println("The specified index does not exist in array.");
			   }
		       
			   catch(ArrayIndexOutOfBoundsException e)
			   {
			   System.out.println("The specified index does not exist in array.");
			   }
			   
			   catch(RuntimeException e)
			   {
				   System.out.println("The specified index does not exist in array.");
			   }
			
			   
	}
}


