package ErrorHandling;

import java.util.Scanner;

public class Demo2 {
	

public static void main(String[] args) {
		
	   Scanner sc = new Scanner(System.in);
	   System.out.println("Enter Divisor");
	   
	    int num1;
		try {
		int num2 = sc.nextInt();
		Calculator ob = new Calculator();
		ob.divide(num1, num2);
		}
	    
		catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
		
		catch(NumberFormatException e)
	    {
	    	e.printStackTrace();
	    }
		

	}

}
