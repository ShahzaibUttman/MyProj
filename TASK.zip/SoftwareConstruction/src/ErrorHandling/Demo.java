package ErrorHandling;

public class Demo {

	public static void main(String[] args) {
		
		try {
		Calculator ob = new Calculator();
	    ob.divide(10, 5);
		}
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
		

	}

}
