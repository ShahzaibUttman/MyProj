package AssertionTask;

import java.util.Scanner;

public class BMICalculator {


	
	    private static Scanner sc;

		public static void main( String args[] ) 
	    { 
	    	double bmi;
	    	System.out.println("Enter Your BMI: ");
	    	sc = new Scanner(System.in); 
	        bmi =sc.nextDouble();
	        
	        assert bmi >= 18 && bmi <= 25 : " Healthy Person";
	        assert bmi > 25  : "Overweight";
	        assert bmi >= 18 : "Underweight";
	        
	    } 
	} 

